#! /bin/bash

shopt -s expand_aliases
#source ~/.bash_profile

source /etc/profile

#获取当前目录下.tbl文件，并获取对应表名
sql_path=./stonedb
# split_tb=$(ls ${sql_path}/*.ddl)
#需要拆分的数据文件
split_tb=(lineitem orders partsupp)
# split_tb=(customer nation supplier part region)
# split_tb=(part nation)
#切割设置
#要分割成的每个小文件的行数line
line=1000000  

#数据库配置
db_host=127.0.0.1
db_port=3306
db_user=root
db_pwd=""
db=tpch  
into_dbtype=stone   #支持参数，ck、mysql、stone



#拆分大SQL文件
function split_file()
{
    for tb_name in ${split_tb[@]}
    do
        echo "$tb_name"
        #获取原文件总行数totalline
        totalline=$(cat $sql_path/$tb_name.tbl | wc -l)
        # echo totalline=$totalline
        a=`expr $totalline / $line`
        b=`expr $totalline % $line` 
        if  [[ $b -eq 0 ]] ;then
            filenum=$a
        else
            filenum=`expr $a + 1`
        fi
        # echo filenum=$filenum
        echo "$tb_name 共有 $totalline行数据,需要切割为 $filenum个文件"


        # 进行文件切割
        i=1        # 修改处2：38 修改为1
        while(( i<=$filenum ))
        do
                echo "切割文件名：$tb_name.tbl.$i"
                #每个小文件要截取行数在原文件范围min,max 
                p=`expr $i - 1`
                min=`expr $p \* $line + 1`
                max=`expr $i \* $line`
                sed -n "$min,$max"p $sql_path/$tb_name.tbl > $sql_path/$tb_name.tbl.$i
                #echo "本次操作没有进行切割"
                # 设置切割文件名
                filename=$sql_path/$tb_name.tbl.$i
                echo "$tb_name.tbl.$i 切割完成！文件名：$filename"
                #StoneDB导入方法，
                mysql -u$db_user  -h$db_host -P$db_port --local-infile -D$db -e "load data local infile '$filename' into table $tb_name fields terminated by '|';" $2>1 > /dev/null &
            i=`expr $i + 1`
        done
    done
}

split_file

